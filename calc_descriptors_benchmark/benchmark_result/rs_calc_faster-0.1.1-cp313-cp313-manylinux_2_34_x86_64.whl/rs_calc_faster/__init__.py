from .rs_calc_faster import *

__doc__ = rs_calc_faster.__doc__
if hasattr(rs_calc_faster, "__all__"):
    __all__ = rs_calc_faster.__all__